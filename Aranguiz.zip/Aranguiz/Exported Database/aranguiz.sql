-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2020 at 08:46 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aranguiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `iptsemi`
--

CREATE TABLE `iptsemi` (
  `Id` int(10) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `account_create` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `iptsemi`
--

INSERT INTO `iptsemi` (`Id`, `fname`, `lname`, `email`, `account_create`) VALUES
(1, 'Robin', 'Aranguiz', 'robin@gmail.com', '2020-11-23 19:28:28'),
(2, 'Robindwa', 'Aranguawdiz', 'robi23n@gmail.com', '2020-11-23 19:30:03');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `Id` int(11) DEFAULT NULL,
  `Age` int(5) DEFAULT NULL,
  `Course` varchar(10) DEFAULT NULL,
  `Year_Level` varchar(5) DEFAULT NULL,
  `Gender` varchar(2) DEFAULT NULL,
  `First_name` varchar(30) DEFAULT NULL,
  `Middle_name` varchar(30) DEFAULT NULL,
  `Last_name` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`Id`, `Age`, `Course`, `Year_Level`, `Gender`, `First_name`, `Middle_name`, `Last_name`) VALUES
(1, 20, 'BSIT', '1', 'M', 'Wallace', 'Delmonte', 'Fabian'),
(2, 25, 'BSCS', '4', 'M', 'Jessie', 'Oiler', 'Grave'),
(3, 21, 'BSCS', '2', 'F', 'Samantha', 'Zupan', 'Westra'),
(4, 19, 'BSCS', '1', 'F', 'Gretchen', 'Dawe', 'Leroy'),
(5, 18, 'BSIT', '1', 'M', 'Farncesco', 'Norcross', 'Arcelia'),
(6, 24, 'BSCS', '2', 'F', 'Talisha', 'Lyall', 'Deng'),
(7, 17, 'BSIT', '1', 'F', 'Wanda', 'Jolei', 'Milling'),
(8, 19, 'BSIT', '1', 'F', 'Gretchen', 'Blessing', 'Cimmino'),
(9, 18, 'BSCS', '1', 'F', 'Emmaline', 'Leland', 'Cygan'),
(10, 28, 'BSIT', '4', 'F', 'Penny', 'Agar', 'Eisert'),
(11, 19, 'BSCS', '1', 'M', 'Jason', 'Karn', 'Klumpp'),
(12, 21, 'BSIT', '3', 'F', 'Jennifer', 'Greenwall', 'Coley'),
(13, 23, 'BSCS', '3', 'F', 'Glinda', 'Hooton', 'Lanz'),
(14, 26, 'BLIS', '3', 'F', 'Emmaline', 'Brittani', 'Rutkowski'),
(15, 28, 'BLIS', '4', 'M', 'Kelle', 'Coley', 'Lacaze');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

CREATE TABLE `tbl_students` (
  `Id` int(11) NOT NULL,
  `First_Name` varchar(30) DEFAULT NULL,
  `Middle_Name` varchar(30) DEFAULT NULL,
  `Last_Name` varchar(30) DEFAULT NULL,
  `Age` int(5) DEFAULT NULL,
  `Course` varchar(10) DEFAULT NULL,
  `Year_Level` varchar(5) DEFAULT NULL,
  `Gender` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_students`
--

INSERT INTO `tbl_students` (`Id`, `First_Name`, `Middle_Name`, `Last_Name`, `Age`, `Course`, `Year_Level`, `Gender`) VALUES
(1, 'Wallace', 'Delmonte', 'Fabian', 20, 'BSIT', '1', 'M'),
(2, 'Jessie', 'Oiler', 'Grave', 25, 'BSCS', '4', 'M'),
(3, 'Samantha', 'Zupan', 'Westra', 21, 'BSCS', '2', 'F'),
(4, 'Gretchen', 'Dawe', 'Leroy', 19, 'BSCS', '1', 'F'),
(5, 'Francesco', 'Norcross', 'Arcelia', 18, 'BSIT', '1', 'M'),
(6, 'Talisha', 'Lyall', 'Deng', 24, 'BSCS', '2', 'F'),
(7, 'Wanda', 'Joiei', 'Milling', 17, 'BSIT', '1', 'F'),
(8, 'Gretchen', 'Blessing', 'Cimmino', 19, 'BSIT', '1', 'F'),
(9, 'Emmaline', 'Leland', 'Cygan', 18, 'BSCS', '1', 'F'),
(10, 'Penny', 'Agar', 'Eisert', 28, 'BSIT', '4', 'F'),
(11, 'Jason', 'Karn', 'Klumpp', 19, 'BSCS', '1', 'M'),
(12, 'Jennifer', 'Greenwall', 'Coley', 21, 'BSIT', '3', 'F'),
(13, 'Glinda', 'Hooton', 'Lanz', 23, 'BSCS', '3', 'F'),
(14, 'Emmaline', 'Brittani', 'Rutkowski', 26, 'BLIS', '3', 'F'),
(15, 'Kelle', 'Coley', 'Lacaze', 28, 'BLIS', '4', 'M');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students_new`
--

CREATE TABLE `tbl_students_new` (
  `Id` int(11) NOT NULL,
  `First_name` varchar(30) DEFAULT NULL,
  `Middle_name` varchar(30) DEFAULT NULL,
  `Last_name` varchar(30) DEFAULT NULL,
  `Date_of_Birth` date DEFAULT NULL,
  `Course` varchar(10) DEFAULT NULL,
  `Year_Level` int(11) DEFAULT NULL,
  `Gender` varchar(2) DEFAULT NULL,
  `Date_Registered` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_students_new`
--

INSERT INTO `tbl_students_new` (`Id`, `First_name`, `Middle_name`, `Last_name`, `Date_of_Birth`, `Course`, `Year_Level`, `Gender`, `Date_Registered`) VALUES
(1, 'Eli', 'Sheley', 'Loan', '1995-12-18', 'BSIT', 2, 'M', '2019-06-18 13:00:36'),
(2, 'Jene', 'Fomby', 'Mannings', '1992-01-21', 'BSIT', 3, 'F', '2019-06-18 10:00:36'),
(3, 'Rosallee', 'Bunner', 'Weber', '1989-08-17', 'BSIT', 4, 'F', '2019-06-18 09:23:11'),
(4, 'Bernardo', 'Linde', 'Kahn', '1990-02-11', 'BSIT', 2, 'M', '2019-06-18 08:20:31'),
(5, 'Adena', 'Saylor', 'Mcmain', '1994-03-16', 'BSCS', 1, 'F', '2019-06-18 13:30:11'),
(6, 'Charmaine', 'Haliburton', 'Talton', '1992-07-18', 'BSCS', 2, 'F', '2019-06-19 23:20:36'),
(7, 'Marlon', 'Hazan', 'Rochin', '1990-09-02', 'BSCS', 2, 'M', '2019-06-19 19:32:36'),
(8, 'Hollis', 'Ellithorpe', 'Sarno', '1988-10-09', 'BSCS', 4, 'M', '2019-06-19 11:23:36'),
(9, 'Earleen', 'Dirk', 'Saylor', '1992-01-11', 'BSCS', 2, 'F', '2019-06-19 15:00:36'),
(10, 'Edwardo', 'Quam', 'Barcelo', '1989-04-22', 'BSCS', 4, 'M', '2019-06-19 15:05:01'),
(11, 'Tisha', 'Quam', 'Milhorn', '1995-05-01', 'BLIS', 1, 'F', '2019-06-20 13:50:26'),
(12, 'Nola', 'Nieves', 'Hartzog', '1993-08-18', 'BLIS', 3, 'F', '2019-06-20 17:30:06'),
(13, 'Reggie', 'Puls', 'Baker', '1991-11-26', 'BLIS', 1, 'M', '2019-06-20 15:40:11'),
(14, 'Roy', 'Beckmann', 'Monroig', '1988-09-24', 'BLIS', 4, 'M', '2019-06-20 15:15:36'),
(15, 'Werner', 'Erdman', 'Mooring', '1989-07-04', 'BLIS', 4, 'M', '2019-06-21 16:25:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `iptsemi`
--
ALTER TABLE `iptsemi`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_students`
--
ALTER TABLE `tbl_students`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_students_new`
--
ALTER TABLE `tbl_students_new`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `iptsemi`
--
ALTER TABLE `iptsemi`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_students`
--
ALTER TABLE `tbl_students`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_students_new`
--
ALTER TABLE `tbl_students_new`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
