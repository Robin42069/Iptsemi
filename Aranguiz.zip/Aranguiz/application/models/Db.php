<?php 


/**
 * 
 */
class Db extends CI_Model
{
	
	public function getdata()
	{
		$table = $this->db->table_exists('iptsemi');
		if ($table) {
			$query = $this->db->get('iptsemi');
			if ($query->num_rows() > 0) {
				return $query->result();
			}
			else{
				return false;
			}
		}

	}
}


 ?>