<?php  
defined('BASEPATH') OR exit('No direct script access allowed');


/**
 * 
 */
class Robin extends CI_Controller
{

	function __construct(){
		parent:: __construct();
		$this->load->model('Db','data');
	}
	
	function index(){
		// echo "Hello World";

		$data['tbl_data'] = $this->data->getdata();

		$this->load->view('sample/index',$data);
	}
}

?>