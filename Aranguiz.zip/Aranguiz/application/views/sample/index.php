<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>	</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
</head>
<body>

<!-- header -->
	<header>
		<div class="head">
			<a href=""><img src=""><span>Web Application</span></a>
		</div>
	</header>
	<!-- end of header -->

	<table border="1" width="100%;">
		<tr>
			<th colspan="7">DATA</th>
		</tr>
		<tr align="center">
			<th>ID</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Email</th>
			<th>Account Created</th>
			<th>Edit</th>
			<th>Delete</th>
		</tr>
		<?php  
			if ($tbl_data) {
				foreach ($tbl_data as $key) {
					?>
					<tr align="center">
						<td><?php echo $key->Id; ?></td>
						<td><?php echo $key->fname; ?></td>
						<td><?php echo $key->lname; ?></td>
						<td><?php echo $key->email; ?></td>
						<td><?php echo $key->account_create; ?></td>
						<td><button id="edit">Edit</button></td>
						<td><button id="delete">Delete</button></td>
					</tr>
					<?php
				}
			}

		?>
		<!-- <tr align="center">
			<td>1</td>
			<td>Robin</td>
			<td>Aranguiz</td>
			<td>robin@gmail.com</td>
			<td>November 23 2020</td>
			<td><button id="edit">Edit</button></td>
			<td><button id="delete">Delete</button></td>
		</tr> -->
	</table>
	
</body>
</html>